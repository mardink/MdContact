<?php
/*
 * @package MDContact
 * @copyright Copyright (c)2013 Martijn Hiddink / mardinkwebdesign.com
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class MdcontactDispatcher extends FOFDispatcher
{
	public $defaultView = 'contacts';
}